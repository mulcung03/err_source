package healthcenter;

import org.springframework.web.bind.annotation.RestController;

@RestController
 public class ReservationController {
 }
