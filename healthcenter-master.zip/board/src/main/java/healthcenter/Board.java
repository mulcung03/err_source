package healthcenter;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;


@Entity
@Table(name="Board_table")
public class Board {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long orderId;
    private String boardYn;

    @PostPersist
    public void onPostPersist(){
        System.out.println("Post Complete !!");
        PostCompleted postCompleted = new PostCompleted();
        BeanUtils.copyProperties(this, postCompleted);
        postCompleted.publishAfterCommit();
    }

    @PostUpdate
    public void onPostUpdate(){
    	System.out.println("Post Cancel  !!");
        PostCanceled postCanceled = new PostCanceled();
        BeanUtils.copyProperties(this, postCanceled);
        postCanceled.publishAfterCommit();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getBoardYn() {
        return boardYn;
    }

    public void setBoardYn(String boardYn) {
        this.boardYn = boardYn;
    }



}
